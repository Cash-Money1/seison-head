
<?PHP
$user_id = $_SESSION["user_id"];
$db->Query("SELECT * FROM db_users_a, db_users_b WHERE db_users_a.id = db_users_b.id AND db_users_a.id = '$user_id'");
$prof_data = $db->FetchArray();
?>
<html>
	<head>
                <link rel="icon" type="image/png" href="/favicon.png" />
		<title>����� ����� - {!TITLE!}</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-1251" />
		<meta name="description" content="{!DESCRIPTION!}">
		<meta name="keywords" content="{!KEYWORDS!}">
		<link href="/style/style.css" rel="stylesheet" type="text/css" /
                <link rel='stylesheet' href='/style/styletable.css' type='text/css' />
		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/functions.js"></script>
		<script type="text/javascript" src="/js/modernizr.custom.79639.js"></script> 
		<link rel="stylesheet" type="text/css" href="/style/common.css" />
        <link rel="stylesheet" type="text/css" href="/style/style.css" />
		<link href='https://fonts.googleapis.com/css?family=Ubuntu&subset=latin,cyrillic' rel='stylesheet' type='text/css'>
		<script type="text/javascript">
function showTime()
 {
  var dat = new Date();
  var H = '' + dat.getHours();
  H = H.length<2 ? '0' + H:H;
  var M = '' + dat.getMinutes();
  M = M.length<2 ? '0' + M:M;
  var S = '' + dat.getSeconds();
  S =S.length<2 ? '0' + S:S;
  var clock = H + ':' + M + ':' + S;
  document
    .getElementById('time_div')
      .innerHTML=clock;
  setTimeout(showTime,1000);  // ������������ 1 ��� � ���.
 }
</script>
	<?
	$dadd=time()-60*60*24*14;
	$db->Query("DELETE FROM tb_posetitel WHERE  datein < '$dadd'");
 $ip = $func->UserIP;

$ip2 = ip2long($ip);
$db->Query("SELECT * FROM tb_posetitel WHERE ip = '$ip2' limit 1");
if($db->NumRows() == 0){
if(isset($_GET["i"])){
$_rid = (intval($_GET["i"]) > 0) ? intval($_GET["i"]) : 1; 

$polzovatel_id = $_rid;
} else{ $polzovatel_id = 1;}
	$db->Query("SELECT user FROM db_users_a WHERE id = '$polzovatel_id' LIMIT 1");
							
							if($db->NumRows() > 0){
							
								$polzovatel_name = $db->FetchRow();
							
							}else{ $polzovatel_id = 1; $polzovatel_name = "First"; }
						
						

$http_ref=$func->Userparse();  
if(strlen($http_ref) >= 3){
if($http_ref!=="timemoney.org" ){
$db->Query("INSERT INTO tb_posetitel (sitein, referer, referer_id, datein, ip) 
				VALUES ('$http_ref','$polzovatel_name','$polzovatel_id','".time()."','$ip2')");
				$db->Query("UPDATE db_users_b SET posetitel = posetitel + 1 WHERE id = '$polzovatel_id'");
			$db->Query("SELECT * FROM tb_posetitel_list WHERE referer_id = '$polzovatel_id' and sitein='$http_ref' limit 1");	
	if($db->NumRows() == 0){
	$db->Query("INSERT INTO tb_posetitel_list (sitein, referer, referer_id) 
				VALUES ('$http_ref','$polzovatel_name','$polzovatel_id')");
	} else {
	$db->Query("UPDATE tb_posetitel_list SET vsego = vsego + 1 WHERE  referer_id = '$polzovatel_id' and sitein='$http_ref'");
			
	}
			
	}			
    }
     }
		
     
		
	
	?>
	</head>
	<body>
			

			
			
			

<div class="head">
<div style="float:left; width:200px; padding:20px 0px 0px 15px;">
<a href="https://vk.com/openseason_biz" target="blank"><img src="/img/vk.png"></a><br><br>
 &nbsp; ����� �� �������:<div id="time_div" style="font-size:20px; font-weight:600; width:90px; margin-left:7px;"></div> <script type="text/javascript">  showTime();</script>
</div>
<div style="float:right; width:150px; margin-right:86px; padding-top:15px;">
<?PHP
$tfstats = time() - 60*60*24;
$db->Query("SELECT
(SELECT COUNT(*) FROM db_users_a) all_users,
(SELECT SUM(insert_sum) FROM db_users_b) all_insert,
(SELECT SUM(payment_sum) FROM db_users_b) all_payment,
(SELECT COUNT(*) FROM db_users_a WHERE date_reg > '$tfstats') new_users");
$stats_data = $db->FetchArray();
?>
<center>
��������<br> ��� ���:<br>
<div style="background:#ecd090; padding:5px 5px 5px 5px; border-radius:6px; margin-bottom:-15px; margin-top:5px; text-align:center; font-size:20px; border:1px solid #c5984e; width:100px;"><b><?=intval(((time() - $config->SYSTEM_START_TIME) / 86400 ) +1); ?></b>-�</div>
<br>
����
</center>
</div>
<div class="clr"></div>
<div style="float:right; margin-top:322px; margin-right:65px;">
<a href="/registration"><img src="/img/enter.png"></a>
</div>
<div class="clr"></div>
<div class="menu">
<a href="/"><img src="/img/btns/index.png"></a>
<a href="/news"><img src="/img/btns/news.png"></a>
<a href="/faq"><img src="/img/btns/faq.png"></a>
<a href="/stats"><img src="/img/btns/stats.png"></a>
<a href="/rules"><img src="/img/btns/rules.png"></a>
<a href="/support"><img src="/img/btns/contacts.png"></a>
</div>
</div>
<div class="wrapper">
<div class="user-panel">
<?PHP include("inc/_leftpanel.php"); ?>
</div>
<div class="content">
<div class="all-content">

















