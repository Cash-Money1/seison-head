<div class="left-panel">
<div style="width:220px; margin-left:25px; padding-top:15px;">
<?PHP

if(isset($_SESSION["user"]) OR isset($_SESSION["admin"])){

	if(isset($_SESSION["admin"]) AND isset($_GET["menu"]) AND $_GET["menu"] == "seasonhunter"){
	
		include("inc/_admin_menu.php");
	
	}elseif(isset($_SESSION["user"])){ 
		?>


<div style="background:#793711; width:205px; color:#e2b467; text-align:center; padding:10px 0px 10px 0px">
����� ����������:<br><b><font size="4" color="#f1cc8f"><?=$prof_data["user"]; ?></font></b>
</div>
<img src="/img/icon.png">
<br><br>

<div style="width:205px;">
<h4>������ ��� �������:</h4>
<div class="line"></div>
<div style="float:left; margin-top:10px; width:40px; margin-right:10px;"><img src="/img/serebro.png" width="35"></div>
<div style="float:left; margin-top:10px; width:140px; font-size:28px;">{!BALANCE_B!}</div>

<div class="clr"></div>
<br>
<h4>������ �� �����:</h4>
<div class="line"></div>
<div style="float:left; margin-top:10px; width:40px; margin-right:10px;"><img src="/img/zoloto.png" width="35"></div>
<div style="float:left; margin-top:10px; width:140px; font-size:28px;">{!BALANCE_P!}</div>
<div class="clr"></div>

</div>

<br>

<a href="/account"><img src="/img/btns/lk.png"></a>
<div class="space"></div>
<a href="/account/bill"><img src="/img/btns/in.png"></a>
<div class="space"></div>
<a href="/account/payment"><img src="/img/btns/out.png"></a>
<div class="space"></div>
<a href="/account/bonus"><img src="/img/btns/bonus.png"></a>
<div class="space"></div>
<a href="/account/forest"><img src="/img/btns/shop.png"></a>
<div class="space"></div>
<a href="/account/meadow"><img src="/img/btns/poleana.png"></a>
<div class="space"></div>
<a href="/account/hunting"><img src="/img/btns/hunt.png"></a>
<div class="space"></div>
<a href="/account/referrals"><img src="/img/btns/ref.png"></a>
<div class="space"></div>
<a href="/exit"><img src="/img/btns/exit.png"></a>


<br><br>

	<?
		}else include("inc/_login.php");
	
}else include("inc/_login.php");
?>
<div class="clr"></div>
</div>
</div>
<div class="left-panel-end">
<?PHP
$tfstats = time() - 60*60*24;
$db->Query("SELECT
(SELECT COUNT(*) FROM db_users_a) all_users,
(SELECT SUM(insert_sum) FROM db_users_b) all_insert,
(SELECT SUM(payment_sum) FROM db_users_b) all_payment,
(SELECT COUNT(*) FROM db_users_a WHERE date_reg > '$tfstats') new_users");
$stats_data = $db->FetchArray();
?>
<br>
<center>
<h3>����������</h3>
</center>

<div style="width:220px; margin-left:18px;">
<img src="/img/user-icon.png" width="37" style="float:left; margin-right:10px;"> <div style="background:#ecd090; padding:5px 5px 5px 5px; border-radius:6px; margin-bottom:5px; margin-top:-3px; text-align:center; font-size:20px; border:1px solid #c5984e; width:160px; margin-left:40px;"><b><?=$stats_data["all_users"]; ?></b> ���.</div>
<div class="clr"></div>
<img src="/img/serebro.png" width="37" style="float:left; margin-right:10px;"> <div style="background:#ecd090; padding:5px 5px 5px 5px; border-radius:6px; margin-bottom:5px; margin-top:-3px; text-align:center; font-size:20px; border:1px solid #c5984e; width:160px; margin-left:40px;"><b><?=sprintf("%.2f",$stats_data["all_insert"] - $stats_data["all_payment"]); ?></b> <font size="3">���.</font></div>
<div class="clr"></div>
<img src="/img/zoloto.png" width="37" style="float:left; margin-right:10px;"> <div style="background:#ecd090; padding:5px 5px 5px 5px; border-radius:6px; margin-top:-3px; text-align:center; font-size:20px; border:1px solid #c5984e; width:160px; margin-left:40px;"><b><?=sprintf("%.2f",$stats_data["all_payment"]); ?></b> <font size="3">���.</font></div>

</div>

</div>